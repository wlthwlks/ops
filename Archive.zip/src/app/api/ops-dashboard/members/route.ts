import { requireOpsViewer } from "@/lib/ops/auth";
import { handleOpsApiError, jsonOk } from "@/lib/ops/api-response";
import { filterMembers, scanMemberHealth } from "@/lib/ops/member-health";
import { severityRank } from "@/lib/ops/member-issue-classifier";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function GET(request: Request) {
  try {
    await requireOpsViewer();
    const url = new URL(request.url);
    const q = url.searchParams.get("q") || undefined;
    const city = url.searchParams.get("city") || undefined;
    const severity = url.searchParams.get("severity") || undefined;
    const issueCode = url.searchParams.get("issueCode") || undefined;
    const serviceAccess = url.searchParams.get("serviceAccess") || undefined;
    const needsAction = url.searchParams.get("needsAction") === "1";
    const missingSlack = url.searchParams.get("missingSlack") === "1";
    const missingStripeId = url.searchParams.get("missingStripeId") === "1";
    const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10));
    const rawSize = parseInt(url.searchParams.get("pageSize") || "100", 10);
    const pageSize = [50, 100, 200].includes(rawSize) ? rawSize : 100;
    const includeChannels = url.searchParams.get("channels") === "1";

    const scan = await scanMemberHealth({
      includeSlack: true,
      includeChannelMembership: includeChannels,
    });

    let filtered = filterMembers(scan.members, {
      q,
      city,
      severity,
      issueCode,
      serviceAccess,
      needsAction,
      missingSlack,
      missingStripeId,
    });

    filtered = [...filtered].sort((a, b) => {
      const sr = severityRank(a.highestSeverity) - severityRank(b.highestSeverity);
      if (sr !== 0) return sr;
      return a.name.localeCompare(b.name);
    });

    const total = filtered.length;
    const start = (page - 1) * pageSize;
    const items = filtered.slice(start, start + pageSize);

    return jsonOk({
      summary: scan.summary,
      total,
      page,
      pageSize,
      members: items,
    });
  } catch (err) {
    return handleOpsApiError(err);
  }
}
