import { requireOpsViewer } from "@/lib/ops/auth";
import { handleOpsApiError, jsonError, jsonOk } from "@/lib/ops/api-response";
import { scanMemberHealth } from "@/lib/ops/member-health";
import { buildSlackJoinEmailPreview } from "@/lib/ops/slack-outreach";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(request: Request) {
  try {
    await requireOpsViewer();
    const body = await request.json();
    const airtableRecordId = String(body.airtableRecordId || "");
    if (!airtableRecordId) {
      return jsonError("BAD_REQUEST", "airtableRecordId required", 400);
    }

    const scan = await scanMemberHealth({ includeSlack: true });
    const member = scan.members.find((m) => m.airtableRecordId === airtableRecordId);
    if (!member) {
      return jsonError("NOT_FOUND", "Member not found in latest scan", 404);
    }

    const preview = buildSlackJoinEmailPreview(member);
    return jsonOk({ preview, mode: scan.summary.mode });
  } catch (err) {
    return handleOpsApiError(err);
  }
}
