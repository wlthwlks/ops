"use client";

// Client page with URL filters

import {useCallback, useEffect, useState, Suspense} from "react";
import { Alert, App, Button, Space, Spin, Table, Tabs, Tag, Typography } from "antd";
import { useSearchParams } from "next/navigation";
import { OpsPageHeader } from "@/components/ops/OpsPageHeader";
import { ErrorState } from "@/components/ops/ErrorState";
import type { MemberHealthRow } from "@/lib/ops/member-health-types";

function BillingIntegrityPageInner() {
  const { message } = App.useApp();
  const searchParams = useSearchParams();
  const [tab, setTab] = useState(searchParams.get("tab") || "overview");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState("read_only");
  const [scannedAt, setScannedAt] = useState<string | null>(null);
  const [missingId, setMissingId] = useState<MemberHealthRow[]>([]);
  const [conflicts, setConflicts] = useState<MemberHealthRow[]>([]);
  const [summary, setSummary] = useState<{
    missingStripeCustomerId: number;
    withServiceAccess: number;
    payingStripeMissingAirtable: number;
  } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ops-dashboard/members?pageSize=100&needsAction=1");
      const json = await res.json();
      if (!res.ok || json.success === false) throw new Error(json.message || res.statusText);
      const members: MemberHealthRow[] = json.members || [];
      setMissingId(
        members.filter((m) =>
          m.issues.some((i) => i.code === "AIRTABLE_MEMBER_MISSING_STRIPE_CUSTOMER_ID")
        )
      );
      setConflicts(
        members.filter((m) =>
          m.issues.some(
            (i) =>
              i.code === "DUPLICATE_AIRTABLE_EMAIL" ||
              i.code === "STRIPE_CUSTOMER_ASSIGNED_TO_MULTIPLE_AIRTABLE_RECORDS" ||
              i.code === "STRIPE_CUSTOMER_ID_CONFLICT"
          )
        )
      );
      setSummary({
        missingStripeCustomerId: json.summary?.missingStripeCustomerId ?? 0,
        withServiceAccess: json.summary?.withServiceAccess ?? 0,
        payingStripeMissingAirtable: json.summary?.payingStripeMissingAirtable ?? 0,
      });
      setMode(json.summary?.mode || "read_only");
      setScannedAt(json.summary?.scannedAt || null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const cliHint =
    "npm run airtable:historical-stripe-repair -- --dry-run\n# Link only:\nnpm run airtable:historical-stripe-repair -- --apply-links\n# Create missing (CLI only — never from dashboard):\nnpm run airtable:historical-stripe-repair -- --apply --create-missing";

  return (
    <div style={{ maxWidth: 1400, margin: "0 auto" }}>
      <OpsPageHeader
        title="Billing Integrity"
        description="Conservative Stripe ↔ Airtable linkage and service-access visibility."
        breadcrumbs={[
          { title: "Members", href: "/members" },
          { title: "Billing Integrity" },
        ]}
        mode={mode}
        scannedAt={scannedAt}
        onRefresh={load}
        refreshing={loading}
      />

      <Alert
        type="warning"
        showIcon
        style={{ marginBottom: 16 }}
        title="This dashboard never creates Airtable Members from Stripe"
        description="Member creation is owned by Memberstack → Make. The invoice.paid webhook only updates/links existing members. Account-wide creation remains a one-time CLI historical repair."
      />

      {error && <ErrorState message={error} onRetry={load} />}

      <Tabs
        activeKey={tab}
        onChange={setTab}
        items={[
          {
            key: "overview",
            label: "Overview",
            children: (
              <Space orientation="vertical" size="middle" style={{ width: "100%" }}>
                <Typography.Paragraph>
                  Service-eligible members: <strong>{summary?.withServiceAccess ?? "—"}</strong>
                  <br />
                  Missing Stripe Customer ID:{" "}
                  <strong>{summary?.missingStripeCustomerId ?? "—"}</strong>
                  <br />
                  Paying Stripe missing Airtable (requires full billing scan / CLI):{" "}
                  <strong>{summary?.payingStripeMissingAirtable ?? 0}</strong>
                </Typography.Paragraph>
                <Typography.Paragraph type="secondary">
                  Full Stripe invoice qualification is intentionally not run on every page load.
                  Use reconcile scripts for account-wide billing scans:
                </Typography.Paragraph>
                <pre
                  style={{
                    background: "#f5f5f5",
                    padding: 12,
                    borderRadius: 8,
                    fontSize: 12,
                    overflow: "auto",
                  }}
                >
                  {`npm run airtable:reconcile-stripe-customers -- --dry-run
npm run airtable:backfill-service-access -- --dry-run`}
                </pre>
              </Space>
            ),
          },
          {
            key: "missing-airtable",
            label: "Paying Stripe, Missing Airtable",
            children: (
              <>
                <Alert
                  type="info"
                  showIcon
                  style={{ marginBottom: 12 }}
                  title="No Create Member button"
                  description="These customers cannot receive city Slack email until an Airtable member exists with a city. Investigate with the historical repair CLI or fix Make registration."
                />
                <Typography.Paragraph>
                  Live orphan detection requires a full Stripe customer/invoice scan (expensive).
                  Use:
                </Typography.Paragraph>
                <pre
                  style={{
                    background: "#f5f5f5",
                    padding: 12,
                    borderRadius: 8,
                    fontSize: 12,
                    whiteSpace: "pre-wrap",
                  }}
                >
                  {cliHint}
                </pre>
                <Button
                  onClick={() => {
                    navigator.clipboard.writeText(cliHint);
                    message.success("CLI commands copied");
                  }}
                >
                  Copy CLI commands
                </Button>
              </>
            ),
          },
          {
            key: "missing-links",
            label: "Missing Stripe Links",
            children: (
              <Table
                size="small"
                loading={loading}
                rowKey={(r) => r.airtableRecordId || r.primaryEmail}
                dataSource={missingId}
                columns={[
                  { title: "Member", dataIndex: "name" },
                  { title: "Email", dataIndex: "primaryEmail" },
                  { title: "City", dataIndex: "city" },
                  {
                    title: "Access",
                    dataIndex: "hasCurrentServiceAccess",
                    render: (v: boolean) =>
                      v ? <Tag color="success">Yes</Tag> : <Tag>No</Tag>,
                  },
                  {
                    title: "Next action",
                    dataIndex: "recommendedNextAction",
                    ellipsis: true,
                  },
                ]}
              />
            ),
          },
          {
            key: "conflicts",
            label: "Conflicts",
            children: (
              <Table
                size="small"
                loading={loading}
                rowKey={(r) => r.airtableRecordId || r.primaryEmail}
                dataSource={conflicts}
                columns={[
                  { title: "Member", dataIndex: "name" },
                  { title: "Email", dataIndex: "primaryEmail" },
                  {
                    title: "Issues",
                    render: (_, r) =>
                      r.issues
                        .filter((i) =>
                          [
                            "DUPLICATE_AIRTABLE_EMAIL",
                            "STRIPE_CUSTOMER_ASSIGNED_TO_MULTIPLE_AIRTABLE_RECORDS",
                            "STRIPE_CUSTOMER_ID_CONFLICT",
                          ].includes(i.code)
                        )
                        .map((i) => i.label)
                        .join("; "),
                  },
                  { title: "Action", dataIndex: "recommendedNextAction", ellipsis: true },
                ]}
              />
            ),
          },
          {
            key: "service-access",
            label: "Service Access",
            children: (
              <Alert
                type="info"
                showIcon
                title="Monotonic service access"
                description="Airtable Service access until is never shortened by cancel/fail events. If Airtable is later than Stripe paid-through, that is informational — not an error. Use npm run airtable:backfill-service-access for bulk recalculation."
              />
            ),
          },
        ]}
      />
    </div>
  );
}


export default function BillingIntegrityPage() {
  return (
    <Suspense fallback={<div style={{ padding: 48, textAlign: "center" }}><Spin size="large" /></div>}>
      <BillingIntegrityPageInner />
    </Suspense>
  );
}
