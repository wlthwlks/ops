"use client";

import { useCallback, useEffect, useMemo, useState, Suspense } from "react";
import {
  Alert,
  App,
  Button,
  Drawer,
  Input,
  Modal,
  Select,
  Space,
  Spin,
  Table,
  Tabs,
  Tag,
  Typography,
} from "antd";
import { useSearchParams } from "next/navigation";
import { OpsPageHeader } from "@/components/ops/OpsPageHeader";
import { ErrorState } from "@/components/ops/ErrorState";
import type { MemberHealthRow } from "@/lib/ops/member-health-types";
import type { ChannelHealthRow } from "@/lib/ops/channel-membership";

function reasonColor(reason?: string) {
  switch (reason) {
    case "in_slack_missing_channel":
      return "orange";
    case "not_in_slack_workspace":
      return "red";
    case "slack_identity_unresolved":
      return "gold";
    case "invalid_or_missing_email":
      return "default";
    case "channel_configuration_missing":
      return "purple";
    default:
      return "default";
  }
}

function SlackAccessPageInner() {
  const { message, modal } = App.useApp();
  const searchParams = useSearchParams();
  const initialTab = searchParams.get("tab") || "needs";
  const [tab, setTab] = useState(initialTab);
  const [mode, setMode] = useState("read_only");
  const [role, setRole] = useState("viewer");
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [members, setMembers] = useState<MemberHealthRow[]>([]);
  const [scannedAt, setScannedAt] = useState<string | null>(null);
  const [channels, setChannels] = useState<ChannelHealthRow[]>([]);
  const [channelScanAt, setChannelScanAt] = useState<string | null>(null);
  const [channelWarnings, setChannelWarnings] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("active");
  const [channelSearch, setChannelSearch] = useState("");
  const [onlyProblems, setOnlyProblems] = useState(true);
  const [selectedChannel, setSelectedChannel] = useState<ChannelHealthRow | null>(null);
  const [drawerTab, setDrawerTab] = useState("present");

  const [suggestions, setSuggestions] = useState<
    Array<{
      airtableRecordId: string;
      name: string;
      airtableEmail: string;
      suggestedSlackEmail: string;
      confidence: string;
      city: string;
    }>
  >([]);
  const [stale, setStale] = useState<
    Array<{ airtableRecordId: string; name: string; slackEmail: string; state: string }>
  >([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [previewOpen, setPreviewOpen] = useState(false);
  const [preview, setPreview] = useState<{
    recipient: string;
    subject: string;
    html: string;
    eligible: boolean;
    eligibilityReasons: string[];
  } | null>(null);
  const [previewMemberId, setPreviewMemberId] = useState<string | null>(null);
  const [workspaceUsers, setWorkspaceUsers] = useState<
    Array<{ name: string; email: string; slackId: string }>
  >([]);
  const [userFilter, setUserFilter] = useState("");

  const loadConfig = useCallback(async () => {
    const res = await fetch("/api/ops-dashboard/config");
    const json = await res.json();
    if (json.mode) setMode(json.mode);
    if (json.role) setRole(json.role);
  }, []);

  const loadNeeds = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        "/api/ops-dashboard/members?missingSlack=1&serviceAccess=current&pageSize=100&page=1"
      );
      const json = await res.json();
      if (!res.ok || json.success === false) throw new Error(json.message || res.statusText);
      setMembers(json.members || []);
      setScannedAt(json.summary?.scannedAt || null);
      setMode(json.summary?.mode || mode);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [mode]);

  const loadResolver = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ops-dashboard/slack/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ write: false }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) throw new Error(json.message || res.statusText);
      setSuggestions(json.writeEligible || json.suggestions || []);
      setStale(json.staleSlackEmails || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/recurring-intros/resolve-emails", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ write: false, verbose: true }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || json.error || res.statusText);
      setWorkspaceUsers(json.slackUsersVerbose || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  const scanChannels = useCallback(async () => {
    if (scanning) return;
    setScanning(true);
    setError(null);
    try {
      const res = await fetch("/api/ops-dashboard/channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ activeOnlyFetch: true }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) {
        throw new Error(json.message || res.statusText);
      }
      setChannels(json.channels || []);
      setChannelScanAt(json.scannedAt || null);
      setChannelWarnings(json.warnings || []);
      message.success(`Scanned ${json.channels?.length || 0} channel(s)`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      message.error(e instanceof Error ? e.message : "Channel scan failed");
    } finally {
      setScanning(false);
    }
  }, [scanning, message]);

  useEffect(() => {
    loadConfig();
  }, [loadConfig]);

  useEffect(() => {
    if (tab === "needs") loadNeeds();
    if (tab === "resolver") loadResolver();
    if (tab === "users") loadUsers();
  }, [tab, loadNeeds, loadResolver, loadUsers]);

  const canMutate = mode === "live" && role === "admin";

  const filteredChannels = useMemo(() => {
    let list = channels;
    if (statusFilter === "active") {
      list = list.filter((c) => c.statusKind === "active" || c.isAllMembersChannel);
    } else if (statusFilter === "paused") {
      list = list.filter((c) => c.statusKind === "paused");
    } else if (statusFilter === "closed") {
      list = list.filter((c) => c.statusKind === "closed");
    }
    if (onlyProblems) {
      list = list.filter(
        (c) =>
          c.missingCount > 0 ||
          c.unresolvedCount > 0 ||
          c.scanStatus === "error" ||
          !c.slackChannelId
      );
    }
    if (channelSearch.trim()) {
      const q = channelSearch.trim().toLowerCase();
      list = list.filter(
        (c) =>
          c.channelName.toLowerCase().includes(q) ||
          c.cityNames.some((n) => n.toLowerCase().includes(q)) ||
          c.slackChannelId.toLowerCase().includes(q)
      );
    }
    return list;
  }, [channels, statusFilter, onlyProblems, channelSearch]);

  const openPreview = async (id: string) => {
    setPreviewMemberId(id);
    const res = await fetch("/api/ops-dashboard/slack-email/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ airtableRecordId: id }),
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      message.error(json.message || "Preview failed");
      return;
    }
    setPreview(json.preview);
    setPreviewOpen(true);
  };

  const sendEmail = async () => {
    if (!previewMemberId) return;
    if (!canMutate) {
      message.warning("Sending requires LIVE mode and admin role");
      return;
    }
    const res = await fetch("/api/ops-dashboard/slack-email/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ airtableRecordId: previewMemberId }),
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      message.error(json.message || "Send failed");
      return;
    }
    const r = json.results?.[0];
    if (r?.status === "sent") message.success("Email accepted by Resend (sent)");
    else message.warning(`${r?.status}: ${r?.error || ""}`);
    setPreviewOpen(false);
    loadNeeds();
  };

  const writeSuggestions = async () => {
    if (!canMutate) {
      message.warning("Writing Slack Email requires LIVE mode and admin role");
      return;
    }
    const updates = suggestions
      .filter((s) => selectedIds.has(s.airtableRecordId))
      .map((s) => ({
        airtableRecordId: s.airtableRecordId,
        suggestedSlackEmail: s.suggestedSlackEmail,
      }));
    if (!updates.length) {
      message.info("Select high-confidence blank-field suggestions");
      return;
    }
    modal.confirm({
      title: `Write ${updates.length} Slack Email value(s)?`,
      content:
        "Only blank Slack Email fields will be written. Non-empty values are never overwritten here.",
      onOk: async () => {
        const res = await fetch("/api/ops-dashboard/slack/resolve", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ write: true, updates }),
        });
        const json = await res.json();
        if (!res.ok || json.success === false) {
          message.error(json.message || "Write failed");
          return;
        }
        message.success(`Written ${json.written}. Skipped ${json.skipped?.length || 0}.`);
        loadResolver();
      },
    });
  };

  const copyText = async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value);
      message.success(`${label} copied`);
    } catch {
      message.error(`Could not copy ${label.toLowerCase()}`);
    }
  };

  const exportChannelCsv = (ch: ChannelHealthRow, kind: "present" | "missing") => {
    const rows = kind === "present" ? ch.present : ch.missing;
    const lines = [
      "name,email,city,slackUserId,reason,action",
      ...rows.map((r) =>
        [r.name, r.primaryEmail, r.city, r.slackUserId, r.reason || "", r.recommendedAction || ""]
          .map((v) => `"${String(v).replace(/"/g, '""')}"`)
          .join(",")
      ),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${ch.channelName.replace(/[^\w.-]+/g, "_")}-${kind}.csv`;
    a.click();
    message.success(`Exported ${kind} members`);
  };

  const filteredUsers = workspaceUsers.filter((u) => {
    if (!userFilter) return true;
    const q = userFilter.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.slackId.toLowerCase().includes(q)
    );
  });

  return (
    <div style={{ maxWidth: 1400, margin: "0 auto" }}>
      <OpsPageHeader
        title="Slack Access"
        description="Resolve Slack identities, inspect city channel membership, and send joining reminders."
        breadcrumbs={[
          { title: "Members", href: "/members" },
          { title: "Slack Access" },
        ]}
        mode={mode}
        scannedAt={channelScanAt || scannedAt}
        onRefresh={() => {
          if (tab === "needs") loadNeeds();
          if (tab === "resolver") loadResolver();
          if (tab === "users") loadUsers();
          if (tab === "channels" || tab === "missing") void scanChannels();
        }}
        refreshing={loading || scanning}
      />

      {mode === "read_only" && (
        <Alert
          type="info"
          showIcon
          style={{ marginBottom: 16 }}
          title="Read-only mode"
          description="Scans and email previews work. Writing Slack Email and sending outreach require LIVE mode and an admin operator."
        />
      )}

      {error && <ErrorState message={error} onRetry={() => setTab(tab)} />}

      <Tabs
        activeKey={tab}
        onChange={setTab}
        items={[
          {
            key: "needs",
            label: "Needs Slack",
            children: (
              <Table
                size="small"
                loading={loading}
                rowKey={(r) => r.airtableRecordId || r.primaryEmail}
                dataSource={members}
                pagination={{ pageSize: 100, showTotal: (t, r) => `${r[0]}–${r[1]} of ${t}` }}
                columns={[
                  { title: "Member", dataIndex: "name" },
                  { title: "Email", dataIndex: "primaryEmail" },
                  { title: "City", dataIndex: "city", width: 120 },
                  {
                    title: "Reason",
                    dataIndex: "slackIdentityState",
                    render: (v: string) => v.replace(/_/g, " "),
                  },
                  {
                    title: "Action",
                    fixed: "right",
                    width: 160,
                    render: (_, r) => (
                      <Button
                        size="small"
                        type="primary"
                        disabled={!r.airtableRecordId}
                        onClick={() => openPreview(r.airtableRecordId!)}
                      >
                        Preview email
                      </Button>
                    ),
                  },
                ]}
              />
            ),
          },
          {
            key: "channels",
            label: "Channels",
            children: (
              <>
                <Space wrap style={{ marginBottom: 12 }}>
                  <Button type="primary" loading={scanning} onClick={() => void scanChannels()}>
                    {scanning ? "Scanning…" : "Refresh channel memberships"}
                  </Button>
                  <Select
                    value={statusFilter}
                    style={{ width: 160 }}
                    onChange={setStatusFilter}
                    options={[
                      { value: "active", label: "Active only" },
                      { value: "paused", label: "Paused" },
                      { value: "closed", label: "Closed" },
                      { value: "all", label: "All statuses" },
                    ]}
                  />
                  <Select
                    value={onlyProblems ? "problems" : "all"}
                    style={{ width: 220 }}
                    onChange={(v) => setOnlyProblems(v === "problems")}
                    options={[
                      { value: "problems", label: "Missing / unresolved only" },
                      { value: "all", label: "All matching channels" },
                    ]}
                  />
                  <Input.Search
                    placeholder="Search channel or city…"
                    allowClear
                    style={{ width: 240 }}
                    onSearch={setChannelSearch}
                    onChange={(e) => setChannelSearch(e.target.value)}
                  />
                  <Typography.Text type="secondary">
                    {filteredChannels.length} channel(s)
                    {channelScanAt ? ` · scanned ${new Date(channelScanAt).toLocaleString()}` : ""}
                  </Typography.Text>
                </Space>
                {channelWarnings.length > 0 && (
                  <Alert
                    type="warning"
                    showIcon
                    style={{ marginBottom: 12 }}
                    title="Partial channel scan"
                    description={channelWarnings.join(" · ")}
                  />
                )}
                {channels.length === 0 && !scanning && (
                  <Alert
                    type="info"
                    showIcon
                    style={{ marginBottom: 12 }}
                    title="No channel scan loaded"
                    description="Click Refresh channel memberships. Works in read_only. Fetches each channel once with bounded concurrency."
                  />
                )}
                <Table
                  size="small"
                  loading={scanning}
                  rowKey={(r) => r.key}
                  dataSource={filteredChannels}
                  scroll={{ x: 1200 }}
                  pagination={{ pageSize: 50 }}
                  onRow={(record) => ({
                    onClick: () => {
                      setSelectedChannel(record);
                      setDrawerTab("missing");
                    },
                    style: { cursor: "pointer" },
                  })}
                  columns={[
                    {
                      title: "Channel",
                      dataIndex: "channelName",
                      fixed: "left",
                      width: 200,
                      render: (v: string, r) => (
                        <span>
                          {r.isAllMembersChannel && <Tag color="blue">all</Tag>}
                          {v}
                        </span>
                      ),
                    },
                    {
                      title: "City",
                      render: (_, r) => r.cityNames.join(", "),
                      width: 140,
                    },
                    {
                      title: "Status",
                      width: 100,
                      render: (_, r) => (
                        <Tag
                          color={
                            r.statusKind === "active"
                              ? "success"
                              : r.statusKind === "paused"
                                ? "warning"
                                : "default"
                          }
                        >
                          {r.statusKind}
                        </Tag>
                      ),
                    },
                    {
                      title: "Slack Channel ID",
                      dataIndex: "slackChannelId",
                      width: 140,
                      render: (v: string) => v || <Tag color="error">missing</Tag>,
                    },
                    {
                      title: "Configured group size",
                      dataIndex: "groupSize",
                      width: 120,
                    },
                    { title: "Expected", dataIndex: "expectedCount", width: 90 },
                    { title: "Present", dataIndex: "presentCount", width: 90 },
                    {
                      title: "Missing",
                      dataIndex: "missingCount",
                      width: 90,
                      render: (v: number) =>
                        v > 0 ? <Tag color="orange">{v}</Tag> : v,
                    },
                    {
                      title: "Unresolved",
                      dataIndex: "unresolvedCount",
                      width: 100,
                      render: (v: number) =>
                        v > 0 ? <Tag color="gold">{v}</Tag> : v,
                    },
                    { title: "Unexpected", dataIndex: "unexpectedCount", width: 100 },
                    {
                      title: "Scan",
                      dataIndex: "scanStatus",
                      width: 100,
                      render: (v: string) => <Tag>{v}</Tag>,
                    },
                  ]}
                />
              </>
            ),
          },
          {
            key: "missing",
            label: "Missing Memberships",
            children: (
              <Table
                size="small"
                loading={scanning}
                rowKey={(r) => `${r.channelKey}-${r.airtableRecordId}-${r.reason}`}
                dataSource={channels.flatMap((c) =>
                  [...c.missing, ...c.unresolved].map((m) => ({
                    ...m,
                    channelKey: c.key,
                    channelName: c.channelName,
                    cityNames: c.cityNames.join(", "),
                  }))
                )}
                pagination={{ pageSize: 100 }}
                columns={[
                  { title: "Channel", dataIndex: "channelName", width: 180 },
                  { title: "Member", dataIndex: "name" },
                  { title: "Email", dataIndex: "primaryEmail" },
                  { title: "City", dataIndex: "city", width: 120 },
                  {
                    title: "Reason",
                    dataIndex: "reason",
                    render: (v?: string) => (
                      <Tag color={reasonColor(v)}>{(v || "").replace(/_/g, " ")}</Tag>
                    ),
                  },
                  { title: "Action", dataIndex: "recommendedAction", ellipsis: true },
                  {
                    title: "Outreach",
                    width: 120,
                    render: (_, r) =>
                      r.reason === "not_in_slack_workspace" ? (
                        <Button size="small" onClick={() => openPreview(r.airtableRecordId)}>
                          Preview
                        </Button>
                      ) : null,
                  },
                ]}
              />
            ),
          },
          {
            key: "resolver",
            label: "Resolver Suggestions",
            children: (
              <>
                <Alert
                  type="warning"
                  showIcon
                  style={{ marginBottom: 12 }}
                  title="Safer write rules"
                  description="Blank Slack Email is fine when primary email already matches Slack. Non-empty Slack Email is never overwritten without explicit override."
                />
                {stale.length > 0 && (
                  <Alert
                    type="error"
                    showIcon
                    style={{ marginBottom: 12 }}
                    title={`${stale.length} stale/deactivated Slack Email value(s)`}
                  />
                )}
                <Space style={{ marginBottom: 12 }}>
                  <Button type="primary" disabled={!canMutate} onClick={() => void writeSuggestions()}>
                    Write selected (blank fields only)
                  </Button>
                </Space>
                <Table
                  size="small"
                  loading={loading}
                  rowKey="airtableRecordId"
                  dataSource={suggestions}
                  rowSelection={{
                    selectedRowKeys: [...selectedIds],
                    onChange: (keys) => setSelectedIds(new Set(keys as string[])),
                  }}
                  columns={[
                    { title: "Name", dataIndex: "name" },
                    { title: "Airtable email", dataIndex: "airtableEmail" },
                    { title: "Suggested Slack Email", dataIndex: "suggestedSlackEmail" },
                    {
                      title: "Confidence",
                      dataIndex: "confidence",
                      render: (v: string) => (
                        <Tag color={v === "high" ? "green" : "orange"}>{v}</Tag>
                      ),
                    },
                    { title: "City", dataIndex: "city" },
                  ]}
                />
              </>
            ),
          },
          {
            key: "users",
            label: "Workspace Users",
            children: (
              <>
                <Input.Search
                  placeholder="Filter users…"
                  allowClear
                  style={{ width: 280, marginBottom: 12 }}
                  onSearch={setUserFilter}
                  onChange={(e) => setUserFilter(e.target.value)}
                />
                <Table
                  size="small"
                  loading={loading}
                  rowKey="slackId"
                  dataSource={filteredUsers}
                  pagination={{ pageSize: 50 }}
                  columns={[
                    { title: "Name", dataIndex: "name" },
                    { title: "Email", dataIndex: "email" },
                    { title: "Slack ID", dataIndex: "slackId" },
                  ]}
                />
              </>
            ),
          },
          {
            key: "config",
            label: "Configuration",
            children: (
              <Alert
                type="info"
                showIcon
                title="Required configuration"
                description={
                  <ul>
                    <li>Airtable table <code>Slack channels</code> fields: Name, Cities, group size, Channel status/donut, Slack Channel ID</li>
                    <li>SLACK_BOT_TOKEN (conversations.members + users:read)</li>
                    <li>SLACK_ALL_MEMBERS_CHANNEL_ID / NAME</li>
                    <li>SLACK_WORKSPACE_INVITE_URL or SLACK_JOIN_URL</li>
                    <li>RESEND_* for outreach; OPS_ADMIN_USER_IDS for writes</li>
                  </ul>
                }
              />
            ),
          },
        ]}
      />

      <Drawer
        open={Boolean(selectedChannel)}
        onClose={() => setSelectedChannel(null)}
        size="large"
        title={selectedChannel?.channelName || "Channel"}
      >
        {selectedChannel && (
          <Space orientation="vertical" size="middle" style={{ width: "100%" }}>
            <div>
              <Tag>{selectedChannel.statusKind}</Tag>
              {selectedChannel.isAllMembersChannel && <Tag color="blue">all-members</Tag>}
              <div style={{ marginTop: 8 }}>
                Cities: {selectedChannel.cityNames.join(", ") || "—"}
              </div>
              <div>
                Slack Channel ID: {selectedChannel.slackChannelId || "—"}{" "}
                {selectedChannel.slackChannelId && (
                  <Button
                    size="small"
                    type="link"
                    onClick={() =>
                      void copyText(selectedChannel.slackChannelId, "Channel ID")
                    }
                  >
                    Copy
                  </Button>
                )}
              </div>
              <div>Configured group size: {selectedChannel.groupSize || "—"}</div>
              <div>
                Expected {selectedChannel.expectedCount} · Present {selectedChannel.presentCount} ·
                Missing {selectedChannel.missingCount} · Unresolved{" "}
                {selectedChannel.unresolvedCount} · Unexpected {selectedChannel.unexpectedCount}
              </div>
              <div>
                Scan: {selectedChannel.scanStatus}
                {selectedChannel.scanError ? ` — ${selectedChannel.scanError}` : ""}
              </div>
              <Space style={{ marginTop: 8 }}>
                <Button size="small" onClick={() => exportChannelCsv(selectedChannel, "present")}>
                  Export present
                </Button>
                <Button size="small" onClick={() => exportChannelCsv(selectedChannel, "missing")}>
                  Export missing
                </Button>
              </Space>
            </div>
            <Tabs
              activeKey={drawerTab}
              onChange={setDrawerTab}
              items={[
                {
                  key: "present",
                  label: `Present (${selectedChannel.presentCount})`,
                  children: (
                    <Table
                      size="small"
                      rowKey="airtableRecordId"
                      dataSource={selectedChannel.present}
                      pagination={{ pageSize: 50 }}
                      columns={[
                        { title: "Name", dataIndex: "name" },
                        { title: "Email", dataIndex: "primaryEmail" },
                        { title: "Slack", dataIndex: "slackDisplayName" },
                        { title: "Identity", dataIndex: "identityMethod" },
                      ]}
                    />
                  ),
                },
                {
                  key: "missing",
                  label: `Missing (${selectedChannel.missingCount})`,
                  children: (
                    <Table
                      size="small"
                      rowKey={(r) => `${r.airtableRecordId}-${r.reason}`}
                      dataSource={selectedChannel.missing}
                      pagination={{ pageSize: 50 }}
                      columns={[
                        { title: "Name", dataIndex: "name" },
                        { title: "Email", dataIndex: "primaryEmail" },
                        {
                          title: "Reason",
                          dataIndex: "reason",
                          render: (v?: string) => (
                            <Tag color={reasonColor(v)}>{(v || "").replace(/_/g, " ")}</Tag>
                          ),
                        },
                        { title: "Action", dataIndex: "recommendedAction" },
                      ]}
                    />
                  ),
                },
                {
                  key: "unresolved",
                  label: `Unresolved (${selectedChannel.unresolvedCount})`,
                  children: (
                    <Table
                      size="small"
                      rowKey="airtableRecordId"
                      dataSource={selectedChannel.unresolved}
                      pagination={{ pageSize: 50 }}
                      columns={[
                        { title: "Name", dataIndex: "name" },
                        { title: "Email", dataIndex: "primaryEmail" },
                        { title: "Identity", dataIndex: "identityState" },
                        { title: "Action", dataIndex: "recommendedAction" },
                      ]}
                    />
                  ),
                },
                {
                  key: "unexpected",
                  label: `Unexpected (${selectedChannel.unexpectedCount})`,
                  children: (
                    <Table
                      size="small"
                      rowKey="slackUserId"
                      dataSource={selectedChannel.unexpected}
                      pagination={{ pageSize: 50 }}
                      columns={[
                        { title: "Slack name", dataIndex: "slackDisplayName" },
                        { title: "Email", dataIndex: "slackEmail" },
                        { title: "User ID", dataIndex: "slackUserId" },
                        { title: "Explanation", dataIndex: "explanation", ellipsis: true },
                      ]}
                    />
                  ),
                },
                {
                  key: "config",
                  label: "Configuration",
                  children: (
                    <pre style={{ fontSize: 12, whiteSpace: "pre-wrap" }}>
                      {JSON.stringify(
                        {
                          Name: selectedChannel.channelName,
                          Cities: selectedChannel.cityNames,
                          "group size": selectedChannel.groupSize,
                          "Channel status/donut": selectedChannel.statusRaw,
                          "Slack Channel ID": selectedChannel.slackChannelId,
                          Timezone: selectedChannel.timezone,
                          "Scheduling mode": selectedChannel.schedulingMode,
                        },
                        null,
                        2
                      )}
                    </pre>
                  ),
                },
              ]}
            />
          </Space>
        )}
      </Drawer>

      <Modal
        open={previewOpen}
        onCancel={() => setPreviewOpen(false)}
        title="Slack joining email preview"
        width={640}
        footer={[
          <Button key="close" onClick={() => setPreviewOpen(false)}>
            Close
          </Button>,
          <Button
            key="send"
            type="primary"
            disabled={!canMutate || !preview?.eligible}
            onClick={() => void sendEmail()}
          >
            Send email
          </Button>,
        ]}
      >
        {preview && (
          <Space orientation="vertical" style={{ width: "100%" }} size="middle">
            <div>
              <strong>To:</strong> {preview.recipient}
            </div>
            <div>
              <strong>Subject:</strong> {preview.subject}
            </div>
            {!preview.eligible && (
              <Alert
                type="warning"
                showIcon
                title="Not eligible to send"
                description={preview.eligibilityReasons.join(" · ")}
              />
            )}
            <div
              style={{
                border: "1px solid #f0f0f0",
                borderRadius: 8,
                padding: 16,
                background: "#fff",
              }}
              dangerouslySetInnerHTML={{ __html: preview.html }}
            />
          </Space>
        )}
      </Modal>
    </div>
  );
}

export default function SlackAccessPage() {
  return (
    <Suspense
      fallback={
        <div style={{ padding: 48, textAlign: "center" }}>
          <Spin size="large" />
        </div>
      }
    >
      <SlackAccessPageInner />
    </Suspense>
  );
}
