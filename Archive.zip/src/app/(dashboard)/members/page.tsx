"use client";

import { useCallback, useEffect, useMemo, useState, Suspense } from "react";
import {
  App,
  Button,
  Drawer,
  Input,
  Select,
  Space,
  Spin,
  Table,
  Tag,
  Typography,
} from "antd";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { OpsPageHeader } from "@/components/ops/OpsPageHeader";
import { IssueSeverityTag } from "@/components/ops/IssueSeverityTag";
import { ErrorState } from "@/components/ops/ErrorState";
import { EmptyState } from "@/components/ops/EmptyState";
import type { MemberHealthRow } from "@/lib/ops/member-health-types";

const PAGE_SIZES = [50, 100, 200] as const;

function MembersDirectoryPageInner() {
  const { message } = App.useApp();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [members, setMembers] = useState<MemberHealthRow[]>([]);
  const [total, setTotal] = useState(0);
  const [mode, setMode] = useState("read_only");
  const [scannedAt, setScannedAt] = useState<string | null>(null);
  const [selected, setSelected] = useState<MemberHealthRow | null>(null);

  // Single source of truth: URL query params
  const q = searchParams.get("q") || "";
  const city = searchParams.get("city") || "";
  const severity = searchParams.get("severity") || "";
  const serviceAccess = searchParams.get("serviceAccess") || "";
  const needsAction = searchParams.get("needsAction") === "1";
  const missingSlack = searchParams.get("missingSlack") === "1";
  const missingStripeId = searchParams.get("missingStripeId") === "1";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
  const rawSize = parseInt(searchParams.get("pageSize") || "100", 10);
  const pageSize = (PAGE_SIZES as readonly number[]).includes(rawSize) ? rawSize : 100;

  const replaceParams = useCallback(
    (patch: Record<string, string | null>, opts?: { resetPage?: boolean }) => {
      const p = new URLSearchParams(searchParams.toString());
      for (const [k, v] of Object.entries(patch)) {
        if (v == null || v === "") p.delete(k);
        else p.set(k, v);
      }
      if (opts?.resetPage) p.set("page", "1");
      if (!p.get("pageSize")) p.set("pageSize", String(pageSize));
      router.replace(`${pathname}?${p.toString()}`);
    },
    [pathname, router, searchParams, pageSize]
  );

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const p = new URLSearchParams();
      if (q) p.set("q", q);
      if (city) p.set("city", city);
      if (severity) p.set("severity", severity);
      if (serviceAccess) p.set("serviceAccess", serviceAccess);
      if (needsAction) p.set("needsAction", "1");
      if (missingSlack) p.set("missingSlack", "1");
      if (missingStripeId) p.set("missingStripeId", "1");
      p.set("page", String(page));
      p.set("pageSize", String(pageSize));
      const res = await fetch(`/api/ops-dashboard/members?${p}`);
      const json = await res.json();
      if (!res.ok || json.success === false) throw new Error(json.message || res.statusText);

      const nextTotal = Number(json.total || 0);
      const maxPage = Math.max(1, Math.ceil(nextTotal / pageSize) || 1);
      if (page > maxPage && nextTotal >= 0) {
        replaceParams({ page: String(maxPage) });
        return;
      }

      setMembers(json.members || []);
      setTotal(nextTotal);
      setMode(json.summary?.mode || "read_only");
      setScannedAt(json.summary?.scannedAt || null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [
    q,
    city,
    severity,
    serviceAccess,
    needsAction,
    missingSlack,
    missingStripeId,
    page,
    pageSize,
    replaceParams,
  ]);

  useEffect(() => {
    load();
  }, [load]);

  const rangeLabel = useMemo(() => {
    if (total === 0) return "0 of 0 members";
    const start = (page - 1) * pageSize + 1;
    const end = Math.min(page * pageSize, total);
    return `${start}–${end} of ${total} members`;
  }, [page, pageSize, total]);

  const exportCsv = () => {
    const headers = [
      "name",
      "email",
      "city",
      "membership",
      "payment",
      "serviceAccessUntil",
      "stripeCustomerId",
      "slackIdentityState",
      "highestSeverity",
      "issues",
    ];
    const lines = [headers.join(",")];
    for (const m of members) {
      lines.push(
        [
          m.name,
          m.primaryEmail,
          m.city,
          m.membership,
          m.payment,
          m.serviceAccessUntil,
          m.stripeCustomerId,
          m.slackIdentityState,
          m.highestSeverity || "",
          m.issues.map((i) => i.code).join("|"),
        ]
          .map((v) => `"${String(v).replace(/"/g, '""')}"`)
          .join(",")
      );
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "members-page.csv";
    a.click();
    URL.revokeObjectURL(url);
    message.success("CSV exported (current page)");
  };

  const copyText = async (value: string, label: string) => {
    try {
      if (!navigator.clipboard?.writeText) {
        throw new Error("Clipboard unavailable");
      }
      await navigator.clipboard.writeText(value);
      message.success(`${label} copied`);
    } catch {
      message.error(`Could not copy ${label.toLowerCase()}`);
    }
  };

  const chips = useMemo(
    () => [
      {
        label: "Needs action",
        active: needsAction,
        onClick: () =>
          replaceParams({ needsAction: needsAction ? null : "1" }, { resetPage: true }),
      },
      {
        label: "Missing Slack",
        active: missingSlack,
        onClick: () =>
          replaceParams({ missingSlack: missingSlack ? null : "1" }, { resetPage: true }),
      },
      {
        label: "Missing Stripe ID",
        active: missingStripeId,
        onClick: () =>
          replaceParams(
            { missingStripeId: missingStripeId ? null : "1" },
            { resetPage: true }
          ),
      },
      {
        label: "Has access",
        active: serviceAccess === "current",
        onClick: () =>
          replaceParams(
            { serviceAccess: serviceAccess === "current" ? null : "current" },
            { resetPage: true }
          ),
      },
    ],
    [needsAction, missingSlack, missingStripeId, serviceAccess, replaceParams]
  );

  return (
    <div style={{ maxWidth: 1400, margin: "0 auto" }}>
      <OpsPageHeader
        title="Member Directory"
        description="Operational directory of Airtable members with Stripe and Slack health."
        breadcrumbs={[{ title: "Members", href: "/members" }, { title: "Directory" }]}
        mode={mode}
        scannedAt={scannedAt}
        onRefresh={load}
        refreshing={loading}
        extra={
          <Button onClick={exportCsv} disabled={!members.length}>
            Export CSV
          </Button>
        }
      />

      <Space wrap style={{ marginBottom: 12 }}>
        <Input.Search
          placeholder="Search name, email, Stripe ID…"
          allowClear
          defaultValue={q}
          onSearch={(v) => replaceParams({ q: v || null }, { resetPage: true })}
          style={{ width: 280 }}
        />
        <Select
          allowClear
          placeholder="Severity"
          style={{ width: 140 }}
          value={severity || undefined}
          onChange={(v) => replaceParams({ severity: v || null }, { resetPage: true })}
          options={[
            { value: "critical", label: "Critical" },
            { value: "high", label: "High" },
            { value: "medium", label: "Medium" },
            { value: "info", label: "Info" },
          ]}
        />
        <Input
          placeholder="City"
          allowClear
          defaultValue={city}
          style={{ width: 140 }}
          onBlur={(e) =>
            replaceParams({ city: e.target.value.trim() || null }, { resetPage: true })
          }
          onPressEnter={(e) =>
            replaceParams(
              { city: (e.target as HTMLInputElement).value.trim() || null },
              { resetPage: true }
            )
          }
        />
        <Button
          onClick={() => {
            router.replace(`${pathname}?page=1&pageSize=100`);
          }}
        >
          Reset filters
        </Button>
      </Space>

      <Space wrap style={{ marginBottom: 16 }}>
        {chips.map((c) => (
          <Tag
            key={c.label}
            color={c.active ? "blue" : "default"}
            style={{ cursor: "pointer" }}
            onClick={c.onClick}
          >
            {c.label}
          </Tag>
        ))}
        <Typography.Text type="secondary">{rangeLabel}</Typography.Text>
      </Space>

      {error && <ErrorState message={error} onRetry={load} />}

      <Table
        size="small"
        loading={loading}
        rowKey={(r) => r.airtableRecordId || r.primaryEmail}
        dataSource={members}
        scroll={{ x: 1100 }}
        onRow={(record) => ({
          onClick: () => setSelected(record),
          style: { cursor: "pointer" },
        })}
        pagination={{
          current: page,
          pageSize,
          total,
          showSizeChanger: true,
          pageSizeOptions: PAGE_SIZES.map(String),
          showTotal: (t, range) => `${range[0]}–${range[1]} of ${t} members`,
          onChange: (p, ps) => {
            replaceParams({
              page: String(p),
              pageSize: String(ps || pageSize),
            });
          },
        }}
        locale={{
          emptyText: (
            <EmptyState
              title="No members match"
              description="Adjust filters or run a fresh scan."
              actionLabel="Scan"
              onAction={load}
            />
          ),
        }}
        columns={[
          { title: "Name", dataIndex: "name", fixed: "left", width: 160 },
          { title: "Email", dataIndex: "primaryEmail", width: 220 },
          { title: "City", dataIndex: "city", width: 120 },
          {
            title: "Access",
            dataIndex: "hasCurrentServiceAccess",
            width: 90,
            render: (v: boolean) =>
              v ? <Tag color="success">Yes</Tag> : <Tag>No</Tag>,
          },
          {
            title: "Stripe",
            dataIndex: "stripeCustomerId",
            width: 140,
            render: (v: string) => (v ? <Tag color="blue">Linked</Tag> : <Tag>Missing</Tag>),
          },
          {
            title: "Slack",
            dataIndex: "slackIdentityState",
            width: 140,
            render: (v: string) => <Tag>{v.replace(/_/g, " ")}</Tag>,
          },
          {
            title: "Severity",
            dataIndex: "highestSeverity",
            width: 100,
            render: (v) => <IssueSeverityTag severity={v} />,
          },
          {
            title: "Next action",
            dataIndex: "recommendedNextAction",
            ellipsis: true,
          },
        ]}
      />

      <Drawer
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        size="large"
        title={selected?.name || "Member"}
      >
        {selected && (
          <Space orientation="vertical" size="middle" style={{ width: "100%" }}>
            <div>
              <Typography.Text type="secondary">Primary email</Typography.Text>
              <div>
                {selected.primaryEmail}{" "}
                <Button
                  size="small"
                  type="link"
                  onClick={(e) => {
                    e.stopPropagation();
                    void copyText(selected.primaryEmail, "Email");
                  }}
                >
                  Copy
                </Button>
              </div>
            </div>
            <div>
              <Typography.Text type="secondary">Airtable record</Typography.Text>
              <div>
                {selected.airtableRecordId}{" "}
                {selected.airtableRecordId && (
                  <Button
                    size="small"
                    type="link"
                    onClick={() => void copyText(selected.airtableRecordId!, "Record ID")}
                  >
                    Copy
                  </Button>
                )}
              </div>
            </div>
            <div>
              <Typography.Text type="secondary">Stripe Customer ID</Typography.Text>
              <div>{selected.stripeCustomerId || "—"}</div>
            </div>
            <div>
              <Typography.Text type="secondary">Service access until</Typography.Text>
              <div>{selected.serviceAccessUntil || "—"}</div>
            </div>
            <div>
              <Typography.Text type="secondary">Slack</Typography.Text>
              <div>
                {selected.slackIdentityState} · {selected.activeSlackDisplayName || "—"} ·{" "}
                {selected.activeSlackUserId || "—"}
              </div>
            </div>
            <div>
              <Typography.Text type="secondary">Channels</Typography.Text>
              <div>
                City: {selected.cityChannelMembership} ({selected.cityChannelName || "—"})
                <br />
                All-members: {selected.allMembersChannelMembership}
              </div>
            </div>
            <div>
              <Typography.Text strong>Issues</Typography.Text>
              {selected.issues.map((i) => (
                <div key={i.code} style={{ marginTop: 8 }}>
                  <IssueSeverityTag severity={i.severity} /> {i.label}
                  <div style={{ fontSize: 12, color: "rgba(0,0,0,0.55)" }}>
                    {i.explanation}
                  </div>
                  <div style={{ fontSize: 12 }}>{i.recommendedAction}</div>
                </div>
              ))}
            </div>
          </Space>
        )}
      </Drawer>
    </div>
  );
}

export default function MembersDirectoryPage() {
  return (
    <Suspense
      fallback={
        <div style={{ padding: 48, textAlign: "center" }}>
          <Spin size="large" />
        </div>
      }
    >
      <MembersDirectoryPageInner />
    </Suspense>
  );
}
