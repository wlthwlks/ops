"use client";

import { Card, Descriptions, Typography } from "antd";
import { RunButton } from "../run-button";

const { Title } = Typography;

export function OpDetailHeader(props: {
  name: string;
  description: string;
  slug: string;
}) {
  return (
    <>
      <Title level={3}>{props.name}</Title>
      <Card size="small" style={{ marginBottom: 24 }}>
        <Descriptions column={2} size="small">
          <Descriptions.Item label="Slug">{props.slug}</Descriptions.Item>
          <Descriptions.Item label="Description">{props.description || "—"}</Descriptions.Item>
          <Descriptions.Item label="Run">
            <RunButton slug={props.slug} />
          </Descriptions.Item>
        </Descriptions>
      </Card>
      <Title level={5} style={{ marginTop: 8 }}>
        Recent runs
      </Title>
    </>
  );
}
