import { getOpsOverview } from "@/lib/queries";
import { OpsTable } from "./ops-table";

export const dynamic = "force-dynamic";

export default async function OpsPage() {
  const ops = await getOpsOverview();

  return (
    <>
      <h3 style={{ margin: "0 0 16px", fontSize: 20, fontWeight: 600 }}>Operations</h3>
      <OpsTable ops={ops} />
    </>
  );
}
