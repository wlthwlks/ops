import type { Metadata } from 'next'
import { DirectoryHeader } from '@/components/directory/directory-header'
import { DirectoryClient } from '@/components/directory/directory-client'
import { SiteNav } from '@/components/site-nav'
import { SiteFooter } from '@/components/site-footer'

export const metadata: Metadata = {
  title: 'Member Directory | WLTH WLKS',
  description:
    'Search the WLTH WLKS community by name, city, field or focus. See what each founder is looking for and what she is happy to help with.',
}

export default function MemberDirectoryPage() {
  return (
    <main className="min-h-dvh overflow-x-hidden">
      <SiteNav />
      <DirectoryHeader />
      <DirectoryClient />
      <SiteFooter />
    </main>
  )
}
