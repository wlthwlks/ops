import type { Metadata } from 'next'
import { SiteNav } from '@/components/site-nav'
import { SiteFooter } from '@/components/site-footer'
import { EventsHeader } from '@/components/events/events-header'
import { SweatpalsWidget } from '@/components/events/sweatpals-widget'

export const metadata: Metadata = {
  title: 'Events | WLTH WLKS',
  description:
    'Browse and book WLTH WLKS events: CITY WLKS, virtual sessions and community socials. Filter by city, type and date.',
}

export default function EventsPage() {
  return (
    <main className="min-h-dvh overflow-x-hidden">
      <SiteNav />
      <EventsHeader />
      <section className="mx-auto w-full min-w-0 max-w-6xl px-5 pb-20 sm:px-8">
        <SweatpalsWidget />
      </section>
      <SiteFooter />
    </main>
  )
}
