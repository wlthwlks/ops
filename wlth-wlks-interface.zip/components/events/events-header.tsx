export function EventsHeader() {
  return (
    <section className="mx-auto w-full min-w-0 max-w-6xl px-5 pb-10 pt-20 sm:px-8 sm:pb-12 sm:pt-24">
      <p className="animate-fade-up text-[11px] font-semibold uppercase tracking-brand text-primary">
        Events
      </p>
      <h1
        className="animate-fade-up mt-4 text-balance text-4xl font-bold uppercase leading-[1.05] tracking-tight text-foreground sm:text-5xl"
        style={{ animationDelay: '0.06s' }}
      >
        Walks, socials &amp; <span className="text-primary">gatherings near you</span>
      </h1>
      <p
        className="animate-fade-up mt-5 max-w-2xl text-pretty text-[15px] font-light leading-relaxed text-muted-foreground sm:text-base"
        style={{ animationDelay: '0.12s' }}
      >
        Browse everything happening across the community. Filter by city, type
        or date, then book your spot on a CITY WLK, virtual session or social in
        just a couple of taps.
      </p>
    </section>
  )
}
