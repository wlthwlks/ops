'use client'

import { useEffect, useRef, useState } from 'react'

const WIDGET_SRC =
  'https://app.staging.sweatpals.com/static/embed/community/events/script.js?communityUsername=wlth_wlks_demo_925264&defaultView=calendar&viewsJson=%5B%22list%22%2C%22calendar%22%2C%22recurring%22%5D&filtersJson=%5B%22fitness-type%22%2C%22Location%22%2C%22type%22%2C%22date-picker%22%2C%22price-range%22%5D&showDescription=false&directToCheckout=false&enableAutoEmbed=true&brandColorHex=0D6D9B&fontFamily=SN%20Skandia&cardStyle=modern&displayTimeMode=first&contentVisibilityJson=%7B%22tag%22%3Atrue%2C%22title%22%3Atrue%2C%22subtitle%22%3Atrue%2C%22howItWorks%22%3Atrue%2C%22membershipIntroOffer%22%3Atrue%2C%22membershipPerExperiencePrice%22%3Atrue%2C%22membershipDescription%22%3Atrue%2C%22membershipInclusions%22%3Atrue%2C%22startTime%22%3Atrue%2C%22duration%22%3Atrue%2C%22coverImage%22%3Atrue%2C%22address%22%3Atrue%2C%22price%22%3Atrue%2C%22priceWithMembership%22%3Atrue%2C%22tags%22%3Atrue%2C%22shareButton%22%3Atrue%2C%22rsvps%22%3Atrue%2C%22capacity%22%3Atrue%2C%22host%22%3Atrue%2C%22coHost%22%3Atrue%2C%22instructor%22%3Atrue%7D&bookingBehavior=open-experience-details&buttonText=Book%20now&animationsEnabled=true&glassEffectEnabled=true&heightMode=auto&spacingsMode=medium&maxWidth=1120&cornerRadius=24&showWidgetTitle=true'

export function SweatpalsWidget() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    // Inject the Sweatpals embed script exactly as provided so its
    // auto-embed can mount the calendar. We keep the markup untouched and
    // only host it inside our branded container.
    const script = document.createElement('script')
    script.src = WIDGET_SRC
    script.async = true
    script.addEventListener('load', () => setLoaded(true))
    container.appendChild(script)

    return () => {
      if (container.contains(script)) {
        container.removeChild(script)
      }
    }
  }, [])

  return (
    <div className="relative">
      {!loaded && (
        <div
          className="flex min-h-[420px] items-center justify-center rounded-3xl border border-border/70 bg-card/40"
          aria-hidden="true"
        >
          <div className="flex flex-col items-center gap-4">
            <span className="size-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <p className="text-[12px] font-light uppercase tracking-brand text-muted-foreground">
              Loading events calendar
            </p>
          </div>
        </div>
      )}
      <div ref={containerRef} className={loaded ? 'block' : 'sr-only'} />
    </div>
  )
}
