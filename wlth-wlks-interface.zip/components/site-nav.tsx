'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'

const LOGO =
  'https://cdn.prod.website-files.com/67d62dc17cb7c0a57f321eeb/699d3fd2186a323fb2d40ea9_WLTHWLKS_BRANDMARK_WHITE_RGB_30CM_W_300PPI.png'

type IconProps = { className?: string }

function YouTubeIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M23.5 6.5a3 3 0 0 0-2.1-2.1C19.5 3.9 12 3.9 12 3.9s-7.5 0-9.4.5A3 3 0 0 0 .5 6.5C0 8.4 0 12 0 12s0 3.6.5 5.5a3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.5.5-5.5s0-3.6-.5-5.5ZM9.6 15.6V8.4l6.2 3.6-6.2 3.6Z" />
    </svg>
  )
}

function TikTokIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M16.5 3c.3 2 1.5 3.6 3.5 4v2.6c-1.3 0-2.5-.3-3.6-.9v6.3a5.9 5.9 0 1 1-5.9-5.9c.3 0 .6 0 .9.1v2.7a3.2 3.2 0 1 0 2.3 3V3h2.8Z" />
    </svg>
  )
}

function InstagramIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className={className}>
      <rect x="2.5" y="2.5" width="19" height="19" rx="5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="4.2" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="17.4" cy="6.6" r="1.2" fill="currentColor" />
    </svg>
  )
}

const socials = [
  { href: 'https://www.youtube.com/@ArtofMondays', label: 'YouTube', Icon: YouTubeIcon },
  { href: 'https://tiktok.com/@artofmondays', label: 'TikTok', Icon: TikTokIcon },
  { href: 'https://www.instagram.com/wlthwlks/', label: 'Instagram', Icon: InstagramIcon },
]

export function SiteNav() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
        <a
          href="https://wlthwlks.com"
          target="_blank"
          rel="noreferrer"
          className="flex items-center transition-opacity hover:opacity-80"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={LOGO} alt="WLTH WLKS" width={104} className="h-6 w-auto" />
        </a>

        {/* Desktop */}
        <nav className="hidden items-center gap-2 md:flex">
          <div className="mr-2 flex items-center gap-1">
            {socials.map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer"
                aria-label={label}
                className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              >
                <Icon className="size-[18px]" />
              </a>
            ))}
          </div>
          <a
            href="/events"
            className="rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Events
          </a>
          <a
            href="/member-directory"
            className="rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Directory
          </a>
          <a
            href="/profile-settings"
            className="rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Update details
          </a>
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-primary px-5 py-2 text-xs font-semibold uppercase tracking-brand text-primary-foreground transition-transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-primary/25"
          >
            Log out
          </a>
        </nav>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          className="flex size-10 items-center justify-center rounded-full border border-border text-foreground md:hidden"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="border-t border-border/70 bg-background/95 backdrop-blur-xl md:hidden">
          <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5">
            <a
              href="/events"
              className="rounded-xl px-4 py-3 text-base font-medium text-foreground transition-colors hover:bg-accent"
            >
              Events
            </a>
            <a
              href="/member-directory"
              className="rounded-xl px-4 py-3 text-base font-medium text-foreground transition-colors hover:bg-accent"
            >
              Directory
            </a>
            <a
              href="/profile-settings"
              className="rounded-xl px-4 py-3 text-base font-medium text-foreground transition-colors hover:bg-accent"
            >
              Update details
            </a>
            <a
              href="/"
              target="_blank"
              rel="noreferrer"
              className="rounded-xl bg-primary px-4 py-3 text-center text-sm font-semibold uppercase tracking-brand text-primary-foreground"
            >
              Log out
            </a>
            <div className="mt-2 flex items-center gap-1 border-t border-border/70 pt-4">
              {socials.map(({ href, label, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  <Icon className="size-5" />
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
