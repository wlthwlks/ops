export type Member = {
  id: string
  name: string
  email: string
  photo: string
  role: string
  company: string
  city: string
  country: string
  field: string
  stage: string
  joined: string
  joinedLabel: string
  isNew: boolean
  openTo: string[]
  lookingFor: string
  offering: string
  bio: string
}

/** The signed-in member, used to resolve "same city" / "same field" filters. */
export const viewer = {
  name: 'Jose',
  city: 'Austin',
  field: 'Technology & SaaS',
  stage: 'Seed',
}

export const OPEN_TO = [
  'Collaboration',
  'Mentoring',
  'Being mentored',
  'Investing',
  'Hiring',
  'Speaking',
] as const

export const members: Member[] = [
  {
    id: 'amara-okafor',
    name: 'Amara Okafor',
    email: 'amara@ledgerloop.co',
    photo: '/members/amara.png',
    role: 'Founder & CEO',
    company: 'LedgerLoop',
    city: 'Austin',
    country: 'United States',
    field: 'Technology & SaaS',
    stage: 'Seed',
    joined: '2026-08-02',
    joinedLabel: 'Joined August 2026',
    isNew: true,
    openTo: ['Collaboration', 'Hiring', 'Being mentored'],
    lookingFor:
      'Intros to fractional CFOs and anyone who has priced usage-based billing well.',
    offering:
      'Happy to walk anyone through raising a seed round without a warm network.',
    bio: 'I build accounting automation for small service businesses. Before LedgerLoop I spent seven years in fintech operations, mostly cleaning up the messes that spreadsheets leave behind, and eventually decided the tooling should just be better. We are eight people, fully remote, and about eighteen months into building something people genuinely rely on. I care a lot about pricing, retention and the unglamorous parts of running a company. Outside of work I am usually on a trail somewhere near the river with a podcast on, and I am always up for a walk that turns into a long conversation about hiring or churn.',
  },
  {
    id: 'priya-raman',
    name: 'Priya Raman',
    email: 'priya@northboundhealth.com',
    photo: '/members/priya.png',
    role: 'Co-founder',
    company: 'Northbound Health',
    city: 'Austin',
    country: 'United States',
    field: 'Health & Wellness',
    stage: 'Series A',
    joined: '2026-03-14',
    joinedLabel: 'Joined March 2026',
    isNew: false,
    openTo: ['Mentoring', 'Collaboration', 'Speaking'],
    lookingFor:
      'Founders who have navigated clinical partnerships and enterprise procurement.',
    offering:
      'Advice on regulated go-to-market, clinical pilots and Series A storytelling.',
    bio: 'Northbound Health helps employers deliver actual preventative care instead of a benefits PDF nobody opens. I came out of a decade in hospital operations, which is where I learned how slowly good ideas move when nobody owns the outcome. We raised our Series A last spring and are now twenty-three people across two cities. I spend most of my time on partnerships and on protecting the team from the chaos that growth creates. I have strong opinions about hiring senior operators early and I am very happy to share the things I got wrong first.',
  },
  {
    id: 'sofia-marchetti',
    name: 'Sofia Marchetti',
    email: 'sofia@casaverde.studio',
    photo: '/members/sofia.png',
    role: 'Founder',
    company: 'Casa Verde Studio',
    city: 'Mexico City',
    country: 'Mexico',
    field: 'Design & Creative',
    stage: 'Bootstrapped',
    joined: '2026-07-21',
    joinedLabel: 'Joined July 2026',
    isNew: true,
    openTo: ['Collaboration', 'Being mentored'],
    lookingFor:
      'Studio owners who moved from client work into a product of their own.',
    offering: 'Brand strategy sanity checks and honest portfolio feedback.',
    bio: 'I run a small branding studio for hospitality and food brands across Latin America. We are four people and deliberately staying small, though I am starting to build a licensed template product so revenue is not tied only to my calendar. Most of my work is helping founders figure out what their business actually stands for before they pick a colour palette. I am bootstrapped, profitable and still occasionally terrified, which I understand is normal. I would love to meet women who have made the jump from services into product without blowing up the thing that already works.',
  },
  {
    id: 'mei-chen',
    name: 'Mei Chen',
    email: 'mei@arcadesupply.com',
    photo: '/members/mei.png',
    role: 'Founder & CEO',
    company: 'Arcade Supply',
    city: 'Singapore',
    country: 'Singapore',
    field: 'Retail & E-commerce',
    stage: 'Series A',
    joined: '2025-11-09',
    joinedLabel: 'Joined November 2025',
    isNew: false,
    openTo: ['Mentoring', 'Investing', 'Collaboration'],
    lookingFor: 'Operators thinking about expanding into Southeast Asia.',
    offering:
      'Supply chain introductions and help pressure-testing unit economics.',
    bio: 'Arcade Supply is a direct to consumer homeware brand that started as a very small experiment in my apartment and now ships across nine markets. I have learned most of what I know from getting inventory wrong in expensive ways. These days I spend my time on margin discipline, retail partnerships and trying to keep the brand feeling like a person rather than a catalogue. I also angel invest in early consumer businesses run by women, usually writing small cheques into companies I would want to buy from myself. Ask me about freight, packaging costs or firing yourself from operations.',
  },
  {
    id: 'eleanor-vance',
    name: 'Eleanor Vance',
    email: 'eleanor@vancecapital.co.uk',
    photo: '/members/eleanor.png',
    role: 'Managing Partner',
    company: 'Vance Capital',
    city: 'London',
    country: 'United Kingdom',
    field: 'Finance & Investing',
    stage: 'Established',
    joined: '2025-09-30',
    joinedLabel: 'Joined September 2025',
    isNew: false,
    openTo: ['Investing', 'Mentoring', 'Speaking'],
    lookingFor:
      'Pre-seed and seed founders in fintech, marketplaces and vertical software.',
    offering:
      'Candid fundraising feedback, and I will tell you if your round is not ready.',
    bio: 'I invest in early stage software and financial infrastructure companies, mostly in Europe and increasingly in the United States. Before moving to the other side of the table I built and sold a payments business, which means I have been the founder on the receiving end of a rushed diligence process and I try hard not to repeat that. I write first cheques between two hundred and fifty thousand and one million. I am genuinely happy to give twenty minutes to any member who wants a read on their deck, even when it is not something I would invest in.',
  },
  {
    id: 'zara-haddad',
    name: 'Zara Haddad',
    email: 'zara@atlaslearn.io',
    photo: '/members/zara.png',
    role: 'Co-founder & CPO',
    company: 'AtlasLearn',
    city: 'Dubai',
    country: 'United Arab Emirates',
    field: 'Education',
    stage: 'Seed',
    joined: '2026-05-18',
    joinedLabel: 'Joined May 2026',
    isNew: false,
    openTo: ['Collaboration', 'Hiring', 'Mentoring'],
    lookingFor: 'Product leaders who have scaled a team past twenty people.',
    offering: 'Product discovery frameworks and roadmap triage.',
    bio: 'AtlasLearn builds vocational training software for employers in the Gulf and North Africa. I run product, which in practice means I spend a lot of time saying no politely. I started out as a teacher, moved into instructional design and then learned to build software because the tools available to us were genuinely bad. We are fourteen people and just closed our seed. The hardest part of this stage is not the product, it is keeping decision making fast while adding people who need context. I like talking to anyone who has solved that well.',
  },
  {
    id: 'naomi-clarke',
    name: 'Naomi Clarke',
    email: 'naomi@thirdshelf.co',
    photo: '/members/naomi.png',
    role: 'Founder',
    company: 'Third Shelf',
    city: 'Austin',
    country: 'United States',
    field: 'Food & Beverage',
    stage: 'Pre-seed',
    joined: '2026-08-11',
    joinedLabel: 'Joined August 2026',
    isNew: true,
    openTo: ['Collaboration', 'Being mentored'],
    lookingFor:
      'Anyone who has gotten a food product onto shelves in a regional grocery chain.',
    offering:
      'Co-packer contacts and a very detailed spreadsheet on small batch costing.',
    bio: 'Third Shelf makes low sugar pantry staples, currently sold at farmers markets and through a small online store while I figure out wholesale. I left a marketing job last year to do this properly and I am still very early, which I have decided to treat as an advantage rather than something to hide. Right now I am learning about co-packers, shelf life testing and how much of this business is logistics rather than recipes. I joined WLTH WLKS because building alone in a kitchen is a fast way to run out of ideas.',
  },
  {
    id: 'hannah-brandt',
    name: 'Hannah Brandt',
    email: 'hannah@rowanlegal.com',
    photo: '/members/hannah.png',
    role: 'Founder & Principal',
    company: 'Rowan Legal',
    city: 'Berlin',
    country: 'Germany',
    field: 'Professional Services',
    stage: 'Bootstrapped',
    joined: '2026-01-27',
    joinedLabel: 'Joined January 2026',
    isNew: false,
    openTo: ['Collaboration', 'Mentoring', 'Speaking'],
    lookingFor:
      'Founders scaling a services firm without simply working more hours.',
    offering:
      'Plain language help with contracts, IP and early employment questions.',
    bio: 'I run a boutique legal practice for technology companies, mostly handling commercial contracts, data protection and the awkward founder agreements people put off for too long. I spent six years at a large firm before deciding I wanted clients I actually spoke to. The practice is bootstrapped and profitable with three lawyers and a paralegal. My current challenge is a very common one for services businesses, which is growing revenue that does not depend entirely on me being in the room. I am always glad to answer a quick legal question for a member.',
  },
]

export const cities = [...new Set(members.map((m) => m.city))].sort()
export const fields = [...new Set(members.map((m) => m.field))].sort()
export const stages = [...new Set(members.map((m) => m.stage))].sort()
