import { Carousel } from './carousel'

const stats = [
  {
    value: '67%',
    text: 'Of you were tired of transactional networking, and ready for authentic sisterhood.',
  },
  {
    value: '80%',
    text: 'of you prefer in-person meetups over virtual meetups...',
  },
  {
    value: '61%',
    text: 'of you order coffees on your walks. 39% go for tea or hot choccys.',
  },
  {
    value: '100%',
    text: 'of you are helping to revolutionise modern networking. Boardrooms are out – beachside walks and matcha lattes are in! Allison x',
  },
]

function StatCard({ value, text }: { value: string; text: string }) {
  return (
    <div className="flex h-full flex-col justify-between rounded-3xl border border-border bg-card p-7 transition-colors hover:border-primary/50 sm:p-8">
      <p className="text-5xl font-bold tracking-tight text-primary sm:text-6xl">
        {value}
      </p>
      <p className="mt-5 text-pretty text-[15px] font-light leading-relaxed text-muted-foreground">
        {text}
      </p>
    </div>
  )
}

export function CommunityStats() {
  return (
    <section className="mx-auto w-full min-w-0 max-w-6xl px-5 sm:px-8">
      <div className="mb-8 flex flex-col gap-2">
        <p className="text-[11px] font-semibold uppercase tracking-brand text-primary">
          By the numbers
        </p>
        <h2 className="text-2xl font-bold uppercase tracking-tight text-foreground sm:text-3xl">
          What the circle is telling us
        </h2>
      </div>

      {/* Desktop grid */}
      <div className="hidden grid-cols-2 gap-5 lg:grid xl:grid-cols-4">
        {stats.map((s) => (
          <StatCard key={s.value} {...s} />
        ))}
      </div>

      {/* Mobile / tablet carousel */}
      <div className="lg:hidden">
        <Carousel ariaLabel="Community statistics">
          {stats.map((s) => (
            <StatCard key={s.value} {...s} />
          ))}
        </Carousel>
      </div>
    </section>
  )
}
