'use client'

import { useEffect, useState } from 'react'

const DASHBOARD_IMG =
  'https://cdn.prod.website-files.com/67d62dc17cb7c0a57f321eeb/695f45d361c133de35ceac10_IMG_3818.JPG'

export function WelcomePanel() {
  // Member first name binds asynchronously (as in the original member area).
  const [firstName, setFirstName] = useState<string | null>(null)

  useEffect(() => {
    const t = setTimeout(() => setFirstName('Jose'), 650)
    return () => clearTimeout(t)
  }, [])

  return (
    <section className="mx-auto max-w-6xl px-5 sm:px-8">
      <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-2xl shadow-black/30">
        <div className="grid gap-0 lg:grid-cols-[1.1fr_0.9fr]">
          {/* Copy */}
          <div className="order-2 p-7 sm:p-10 lg:order-1">
            <p className="mb-3 text-[11px] font-semibold uppercase tracking-brand text-primary">
              Your circle
            </p>

            <h2 className="flex flex-wrap items-baseline gap-x-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              <span>Welcome back,</span>
              {firstName ? (
                <span className="text-primary">{firstName}</span>
              ) : (
                <span
                  className="inline-block h-8 w-24 animate-pulse rounded-md bg-muted align-middle sm:h-9"
                  aria-hidden="true"
                />
              )}
            </h2>

            <div className="mt-6 space-y-4 text-[15px] font-light leading-relaxed text-muted-foreground">
              <p>
                You’ve just stepped into a global circle of women who walk with
                vision.
              </p>
              <p>
                WLTH WLKS is more than networking, it’s nourishment and together
                we’re creating a new standard of connection for entrepreneurial
                women...
              </p>
              <p>
                One that’s{' '}
                <strong className="font-semibold text-foreground">
                  intentional
                </strong>
                ,{' '}
                <strong className="font-semibold text-foreground">
                  inspired
                </strong>
                , and rooted in real-life movement and{' '}
                <strong className="font-semibold text-foreground">
                  meaningful conversations
                </strong>
                .
              </p>
              <p className="font-normal text-foreground/90">
                Each month you&apos;ll be introduced with up to five other
                likeminded women in your city, twice per month.
              </p>
              <p>
                Before you jump in, we suggest reading this{' '}
                <a
                  href="https://app.notion.com/p/Getting-Started-with-WLTH-WLKS-35d8c0a31eb48032a29fff39079f61dd?source=copy_link"
                  target="_blank"
                  rel="noreferrer"
                  className="font-semibold text-primary underline decoration-primary/40 underline-offset-4 transition-colors hover:decoration-primary"
                >
                  Getting Started with WLTH&nbsp;WLKS
                </a>{' '}
                guide.
              </p>
              <p>
                Expect thoughtful dialogue, aligned energy, and the kind of
                support that reminds you:{' '}
                <strong className="font-semibold text-foreground">
                  you’re not building alone.
                </strong>
              </p>
              <p>
                Follow the buttons in the navigation menu above or{' '}
                <a
                  href="/profile-settings"
                  className="font-semibold text-primary underline decoration-primary/40 underline-offset-4 transition-colors hover:decoration-primary"
                >
                  click here
                </a>{' '}
                to update your details.
              </p>
            </div>
          </div>

          {/* Image */}
          <div className="relative order-1 min-h-56 overflow-hidden lg:order-2 lg:min-h-full">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={DASHBOARD_IMG}
              alt="WLTH WLKS members enjoying a walk together"
              className="size-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent lg:bg-gradient-to-l" />
          </div>
        </div>
      </div>
    </section>
  )
}
