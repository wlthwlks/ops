const HERO_IMG =
  'https://framerusercontent.com/images/ZWx0YzGf2TsVqPekBx6y2yTfWnc.jpg?width=1200&height=675'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={HERO_IMG}
          alt=""
          aria-hidden="true"
          className="size-full object-cover object-[center_30%]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/55 via-background/70 to-background" />
        <div className="absolute inset-0 grain opacity-60" />
      </div>

      <div className="relative mx-auto flex min-h-[62vh] max-w-4xl flex-col items-center justify-center px-5 py-24 text-center sm:min-h-[68vh] sm:px-8">
        <span className="animate-fade-up mb-6 rounded-full border border-border/80 bg-background/40 px-4 py-1.5 text-[11px] font-medium uppercase tracking-brand text-muted-foreground backdrop-blur-sm">
          Member Home
        </span>
        <h1
          className="animate-fade-up text-balance text-4xl font-bold uppercase leading-[1.05] tracking-tight text-foreground sm:text-6xl"
          style={{ animationDelay: '0.08s' }}
        >
          Some of the best conversations start with a{' '}
          <span className="text-primary">walk.</span>
        </h1>
        <p
          className="animate-fade-up mt-6 max-w-md text-pretty text-base font-light leading-relaxed text-muted-foreground sm:text-lg"
          style={{ animationDelay: '0.16s' }}
        >
          Real connections, in real life, with women who get it.
        </p>
        <div
          className="animate-fade-up mt-9 flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row"
          style={{ animationDelay: '0.24s' }}
        >
          <a
            href="https://women.wlthwlks.com/apply"
            target="_blank"
            rel="noreferrer"
            className="w-full rounded-full bg-primary px-8 py-3.5 text-xs font-bold uppercase tracking-brand text-primary-foreground transition-transform hover:-translate-y-0.5 hover:shadow-xl hover:shadow-primary/30 sm:w-auto"
          >
            Join WLTH WLKS
          </a>
          <a
            href="./wlthwlks?mode=light&siteId=f7766831b06f1307b7e285971875456b116689d28f0c44cff10163d32d4cfe0e#how-it-works"
            className="w-full rounded-full border border-border bg-background/30 px-8 py-3.5 text-xs font-medium uppercase tracking-brand text-foreground backdrop-blur-sm transition-colors hover:border-foreground/50 hover:bg-background/50 sm:w-auto"
          >
            See How It Works
          </a>
        </div>
      </div>
    </section>
  )
}
