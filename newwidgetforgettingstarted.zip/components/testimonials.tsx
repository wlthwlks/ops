import { Carousel } from './carousel'

const reviews = [
  { quote: 'Great first meetup, can’t wait for the next one!' },
  {
    quote:
      'The Melbourne girls had a great time. coconut caps + biz chats = brilliant combo.',
  },
  {
    quote:
      'A riverside walk followed by business chit-chat. Perfect way to start the week.',
  },
  { quote: 'We’ve already made it a recurring event. WLTH WLKS is awesome.' },
]

function ReviewCard({ quote }: { quote: string }) {
  return (
    <figure className="flex h-full flex-col justify-center rounded-3xl border border-border bg-card/60 p-8 text-center sm:p-10">
      <span
        aria-hidden="true"
        className="mb-4 font-serif text-5xl leading-none text-primary/70"
      >
        &ldquo;
      </span>
      <blockquote className="text-balance text-lg font-light leading-relaxed text-foreground sm:text-xl">
        {quote}
      </blockquote>
    </figure>
  )
}

export function Testimonials() {
  return (
    <section className="mx-auto w-full min-w-0 max-w-3xl px-5 sm:px-8">
      <div className="mb-8 text-center">
        <p className="text-[11px] font-semibold uppercase tracking-brand text-primary">
          From the walks
        </p>
        <h2 className="mt-2 text-2xl font-bold uppercase tracking-tight text-foreground sm:text-3xl">
          Loved by members
        </h2>
      </div>
      <Carousel ariaLabel="Member reviews" autoPlayMs={6000}>
        {reviews.map((r, i) => (
          <ReviewCard key={i} quote={r.quote} />
        ))}
      </Carousel>
    </section>
  )
}
