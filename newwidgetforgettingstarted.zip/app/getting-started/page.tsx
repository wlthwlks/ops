import type { Metadata } from 'next'
import { GsHero } from '@/components/getting-started/gs-hero'
import { MonthlyRhythm } from '@/components/getting-started/monthly-rhythm'
import { MembershipPillars } from '@/components/getting-started/membership-pillars'
import { MembershipTips } from '@/components/getting-started/membership-tips'
import { CommunityGuidelines } from '@/components/getting-started/community-guidelines'
import { FaqSection } from '@/components/getting-started/faq-section'
import { ClosingCta } from '@/components/getting-started/closing-cta'
import { SiteFooter } from '@/components/site-footer'

export const metadata: Metadata = {
  title: 'Getting Started | WLTH WLKS',
  description:
    'Everything you need to make the most of your WLTH WLKS membership: how it works, what to expect each month, community guidelines, and answers to common questions.',
}

export default function GettingStartedPage() {
  return (
    <main className="min-h-dvh overflow-x-hidden">
      <GsHero />
      <div className="flex flex-col gap-20 py-20 sm:gap-28 sm:py-28">
        <MonthlyRhythm />
        <MembershipPillars />
        <MembershipTips />
        <CommunityGuidelines />
        <FaqSection />
        <ClosingCta />
      </div>
      <SiteFooter />
    </main>
  )
}
