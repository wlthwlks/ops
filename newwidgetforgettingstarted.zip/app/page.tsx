import { Hero } from '@/components/hero'
import { WelcomePanel } from '@/components/welcome-panel'
import { CommunityStats } from '@/components/community-stats'
import { Testimonials } from '@/components/testimonials'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <main className="min-h-dvh overflow-x-hidden">
      <Hero />
      <div className="flex flex-col gap-20 py-20 sm:gap-24 sm:py-24">
        <WelcomePanel />
        <CommunityStats />
        <Testimonials />
      </div>
      <SiteFooter />
    </main>
  )
}
